export type EffectType = 'autoclick' | 'clickPower' | 'multiplier' | 'passive';

export interface Upgrade {
    id: string;
    label: string;
    subLabel: string;
    baseCost: number;
    multiplier: number;
    effectType: EffectType;
    effectValue: number;
}

const UPGRADES: Record<string, Upgrade> = {
    union: {
        id: 'union',
        label: 'union worker',
        subLabel: '+1 click per second',
        baseCost: 50,
        multiplier: 1.2,
        effectType: 'autoclick',
        effectValue: 1,
    },
    clickPower: {
        id: 'clickPower',
        label: 'citizen worker',
        subLabel: '+1 power to the click',
        baseCost: 20,
        multiplier: 1.30,
        effectType: 'clickPower',
        effectValue: 1,
    },
    jury: {
        id: 'jury',
        label: 'jury warden',
        subLabel: '+2 clicks per second',
        baseCost: 250,
        multiplier: 1.15,
        effectType: 'autoclick',
        effectValue: 2,
    }
};

export default UPGRADES;