import UPGRADES, { type Upgrade } from './upgradesConfig';
import { type GameState } from '../hooks/useGameState';

export function getUpgradeConfig(id: string): Upgrade | null {
    return UPGRADES[id] ?? null;
}

export function calculateCost(config: Upgrade, currentCount: number): number {
    return Math.floor(config.baseCost * Math.pow(config.multiplier, currentCount));
}

export function getClickPower(state: GameState): number {
    let power = 1; 
    const count = state.upgrades['clickPower'] || 0;
    const cfg = UPGRADES['clickPower'];
    if (cfg) {
        power += count * cfg.effectValue;
    }
    return power;
}

export function getTotalCPS(state: GameState): number {
    let cps = 0;
    for (const id in state.upgrades) {
        const cfg = getUpgradeConfig(id);
        if (!cfg) continue;
        const count = state.upgrades[id] || 0;
        if (cfg.effectType === 'autoclick') {
            cps += cfg.effectValue * count;
        }
    }
    return cps;
}