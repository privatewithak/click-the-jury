
import UPGRADES, { type Upgrade } from './upgradesConfig';

export function getUpgradeConfig(id: string): Upgrade | null {
    return UPGRADES[id] ?? null;
}

export function calculateCost(config: Upgrade, currentCount: number): number {
    return Math.floor(config.baseCost * Math.pow(config.multiplier, currentCount));
}

export function getTotalCPS(state: GameState) {
    let cps = 0;

    for (const id in state.upgrades) {
        const cfg = getUpgradeConfig(id);
        if (!cfg) continue;
        const count = state.upgrades[id] || 0;
        if (cfg.effectType === 'autoclick') {
            cps += cfg.effectValue * count;
        }
    }

    return cps;
}