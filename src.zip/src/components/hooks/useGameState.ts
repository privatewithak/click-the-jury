import { useReducer, useEffect, useRef, useCallback, use } from 'react';
import { calculateCost, getTotalCPS, getClickPower, getUpgradeConfig } from '../components/shoplogic/upgradesManager';

export type UpgradesMap = Record<string, number>;

export interface GameState {
    totalClicks: number;
    baseClickPower: number;
    upgrades: UpgradesMap;
}

type Action = 
    | { type: 'CLICK' }
    | { type: 'TICK'; deltaMs: number }
    | { type: 'BUY_UPGRADE'; id: string }
    | { type: 'SET_STATE'; state: Partial<GameState> };

const initialState: GameState = {
    totalClicks: 0,
    baseClickPower: 1,
    upgrades: {}
};

function reducer(state: GameState, action: Action): GameState {
    switch (action.type) {
        case 'CLICK': {
            const clickPower = getClickPower(state);
            return { ...state, totalClicks: state.totalClicks + clickPower };
        }
        case 'TICK': {
            const cps = getTotalCPS(state);
            const gained = cps * (action.deltaMs / 1000);
            return { ...state, totalClicks: state.totalClicks + gained };
        }
        case 'BUY_UPGRADE': {
            const cfg = getUpgradeConfig(action.id);
            if (!cfg) return state;
            const cur = state.upgrades[action.id] || 0;
            const cost = calculateCost(cfg, cur);
            if (state.totalClicks < cost) return state;
            const upgrades = { ...state.upgrades, [action.id]: cur + 1 };
            return { ...state, totalClicks: state.totalClicks - cost, upgrades };
        }
        case 'SET_STATE': {
            return { ...state, ...action.state };
        }
        default:
            return state;
    }
}    


export default function useGameState() {
    const [state, dispatch] = useReducer(reducer, initialState);

    const lastRef = useRef<number | null>(null);
    useEffect(() => {
        let rafId = 0;

        function loop(ts: number) {
            if (lastRef.current === null) lastRef.current = ts;
            const delta = ts - lastRef.current;
            if (delta >= 100) {
                dispatch({ type: 'TICK', deltaMs: delta });
                lastRef.current = ts;
            }
            rafId = requestAnimationFrame(loop);
            
        }
        rafId = requestAnimationFrame(loop);

        return () => {
            cancelAnimationFrame(rafId);
        };
    }, []);

    const click = useCallback(() => dispatch({ type: 'CLICK' }), []);
    const buyUpgrade = useCallback((id: string) => {
        dispatch({ type: 'BUY_UPGRADE', id });
    }, []);

    return { state, dispatch, click, buyUpgrade, getTotalCPS: () => getTotalCPS(state), getClickPower: () => getClickPower(state) };
}